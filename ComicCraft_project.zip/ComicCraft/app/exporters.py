from datetime import datetime
import re

from fpdf import FPDF
from app.config import EXPORTS_DIR


def _clean_text(value) -> str:
    """Convert any generated value into safe printable text."""
    if value is None:
        return ""
    return str(value).replace("\x00", "").strip()


def _wrap_long_words(text: str, max_word_length: int = 35) -> str:
    """Prevent fpdf2 from failing when a word has no break points."""
    text = _clean_text(text)
    if not text:
        return ""

    words = re.split(r"(\s+)", text)
    fixed = []
    for item in words:
        if item.isspace() or len(item) <= max_word_length:
            fixed.append(item)
            continue

        chunks = [item[i:i + max_word_length] for i in range(0, len(item), max_word_length)]
        fixed.append("\u200b".join(chunks))

    return "".join(fixed)


def _write_text(pdf: FPDF, text: str, height: float = 7) -> None:
    """Write text using the complete printable width and reset the cursor."""
    text = _wrap_long_words(text)
    if not text:
        return

    pdf.multi_cell(
        w=pdf.epw,
        h=height,
        text=text,
        new_x="LMARGIN",
        new_y="NEXT",
    )


def save_pdf(layout):
    filename = f"comic_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.pdf"
    output_path = EXPORTS_DIR / filename

    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout:
        pdf.add_page()

        pdf.set_font("Helvetica", "B", 18)
        _write_text(
            pdf,
            f"Panel {panel.get('panel_number', '')}: {panel.get('title', '')}",
            height=10,
        )
        pdf.ln(4)

        image_path = panel.get("image_path")
        if image_path:
            pdf.image(str(image_path), x=15, w=180)
            pdf.ln(5)

        pdf.set_font("Helvetica", "I", 11)
        _write_text(pdf, panel.get("scene_description", ""))
        pdf.ln(3)

        pdf.set_font("Helvetica", "B", 11)
        _write_text(pdf, "Caption: " + _clean_text(panel.get("caption", "")))

        pdf.set_font("Helvetica", "", 11)
        _write_text(pdf, "Narration: " + _clean_text(panel.get("narration", "")))
        _write_text(pdf, "Dialogue: " + _clean_text(panel.get("dialogue", "")))

    pdf.output(str(output_path))
    return output_path
