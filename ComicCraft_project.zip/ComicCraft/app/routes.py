from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from app.config import TEMPLATES_DIR
from app.schemas import PromptRequest
from app.gemini_client import generate_outline, generate_story
from app.image_generator import generate_image
from app.layout_builder import build_comic_layout
from app.exporters import save_pdf

router = APIRouter()
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


def create_comic(data: PromptRequest):
    outline = generate_outline(data)
    story = generate_story(data, outline)
    image_paths = [generate_image(panel["image_prompt"], panel["panel_number"]) for panel in story]
    layout = build_comic_layout(story, image_paths)
    pdf_path = save_pdf(layout)
    return {
        "title": f"{data.character_name}'s Comic: {data.story_prompt[:60]}",
        "layout": layout,
        "pdf_url": f"/static/exports/{pdf_path.name}",
    }


@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@router.post("/generate", response_class=HTMLResponse)
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        data = PromptRequest(
            story_prompt=story_prompt,
            character_name=character_name,
            setting=setting,
            tone=tone,
            art_style=art_style,
        )
        result = create_comic(data)
        return templates.TemplateResponse("comic_preview.html", {"request": request, **result})
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Comic generation failed: {exc}") from exc


@router.post("/generate-comic/json")
async def generate_json(data: PromptRequest):
    try:
        result = create_comic(data)
        return {
            "title": result["title"],
            "panels": result["layout"],
            "pdf_url": result["pdf_url"],
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Comic generation failed: {exc}") from exc


@router.post("/test-image")
async def test_image(prompt: str = Form(...)):
    path = generate_image(prompt, 0)
    return {"image_url": f"/static/panels/{path.name}"}


@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request):
    return templates.TemplateResponse("export_success.html", {"request": request})
