import json
from app.config import GEMINI_API_KEY, GEMINI_MODEL


def _client():
    if not GEMINI_API_KEY:
        return None
    from google import genai
    return genai.Client(api_key=GEMINI_API_KEY)


def _json_from_text(text: str):
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.replace("```json", "", 1).replace("```", "").strip()
    return json.loads(cleaned)


def _is_nature_story(data) -> bool:
    source = " ".join(
        [
            getattr(data, "story_prompt", ""),
            getattr(data, "setting", ""),
            getattr(data, "tone", ""),
        ]
    ).lower()
    keywords = (
        "nature", "forest", "tree", "trees", "environment", "earth", "river",
        "wildlife", "animal", "animals", "plant", "plants", "pollution",
        "plastic", "green", "climate", "save nature", "save earth",
    )
    return any(keyword in source for keyword in keywords)


def _nature_outline(data):
    character = data.character_name
    setting = data.setting or "a green natural environment"
    return [
        ("A Beautiful Beginning", f"{character} visits {setting} and admires the trees, flowers, birds, and fresh air."),
        ("A Problem in Nature", f"{character} notices plastic waste and pollution harming the plants, water, and animals."),
        ("A Promise to Help", f"{character} decides to protect nature and says that the Earth is everyone's home."),
        ("Working Together", f"{character} joins friends to collect waste, recycle plastic, save water, and plant trees."),
        ("A Greener Tomorrow", f"The place becomes clean and green, and {character} encourages everyone to protect nature every day."),
    ]


def _generic_outline(data):
    character = data.character_name
    setting = data.setting
    prompt = data.story_prompt.strip()
    return [
        ("The Beginning", f"{character} begins the story in {setting}. Story idea: {prompt}"),
        ("A New Discovery", f"{character} discovers an important clue connected to the story: {prompt}"),
        ("The Challenge", f"{character} faces a challenge while trying to complete the goal described in the story."),
        ("The Turning Point", f"{character} finds a useful idea and takes action to solve the problem."),
        ("A Positive Ending", f"{character} completes the next step and shares a meaningful lesson from the experience."),
    ]


def demo_outline(data):
    entries = _nature_outline(data) if _is_nature_story(data) else _generic_outline(data)
    return [
        {
            "panel_number": number,
            "title": title,
            "scene_description": description,
            "image_prompt": (
                f"{data.art_style} comic illustration, consistent character "
                f"{data.character_name}, setting {data.setting}, {description}, "
                "clear expressive faces, readable composition, no text inside the image"
            ),
        }
        for number, (title, description) in enumerate(entries, start=1)
    ]


def _fallback_story(data, outline):
    if _is_nature_story(data):
        dialogues = [
            f"{data.character_name}: Nature is beautiful!",
            f"{data.character_name}: We must stop pollution.",
            f"{data.character_name}: The Earth is our home.",
            f"{data.character_name}: Let's plant trees together!",
            f"{data.character_name}: Save nature, save life!",
        ]
        narrations = [
            "The peaceful natural place is full of life.",
            "The waste begins to harm the environment.",
            "The character chooses to take responsibility.",
            "Friends and community members work together.",
            "The environment becomes cleaner and healthier.",
        ]
    else:
        dialogues = [
            f"{data.character_name}: I can do this!",
            f"{data.character_name}: I found an important clue.",
            f"{data.character_name}: This challenge is difficult.",
            f"{data.character_name}: I know how to solve it.",
            f"{data.character_name}: We learned something valuable today!",
        ]
        narrations = [
            "The story begins and the character takes the first step.",
            "A new discovery changes the direction of the story.",
            "A challenge tests the character's courage.",
            "A creative solution brings hope.",
            "The character finishes the mission and learns a lesson.",
        ]

    for index, panel in enumerate(outline):
        panel["caption"] = f"Scene {panel['panel_number']}: {panel['title']}"
        panel["narration"] = narrations[index % len(narrations)]
        panel["dialogue"] = dialogues[index % len(dialogues)]
    return outline


def generate_outline(data):
    client = _client()
    if client is None:
        return demo_outline(data)

    prompt = f"""
Create a five-panel comic outline based directly on the user's story prompt.
Return only valid JSON, an array of exactly five objects.
Each object must contain: panel_number, title, scene_description, image_prompt.
Make every panel different and make the scenes follow the user's story.
Do not replace the user's topic with a generic adventure.
Keep the same main character visually consistent in all image prompts.
Story prompt: {data.story_prompt}
Character: {data.character_name}
Setting: {data.setting}
Tone: {data.tone}
Art style: {data.art_style}
"""
    response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
    return _json_from_text(response.text)


def generate_story(data, outline):
    client = _client()
    if client is None:
        return _fallback_story(data, outline)

    prompt = f"""
Expand the following five-panel comic outline with caption, narration, and dialogue.
Return only valid JSON as an array of five objects.
Preserve all existing fields and add: caption, narration, dialogue.
Make the dialogue short, different in each panel, and directly related to the user's story.
Do not repeat the same dialogue in every panel.
Story prompt: {data.story_prompt}
Character: {data.character_name}
Tone: {data.tone}
Outline: {json.dumps(outline)}
"""
    response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
    return _json_from_text(response.text)
