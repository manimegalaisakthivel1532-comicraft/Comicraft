def build_comic_layout(panels, image_paths):
    layout = []
    for panel, image_path in zip(panels, image_paths):
        item = dict(panel)
        item["image_path"] = str(image_path)
        item["image_url"] = f"/static/panels/{image_path.name}"
        layout.append(item)
    return layout
