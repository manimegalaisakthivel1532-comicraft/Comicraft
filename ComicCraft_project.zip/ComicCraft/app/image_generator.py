import io
import uuid
import httpx
from PIL import Image, ImageDraw
from app.config import HF_API_KEY, HF_IMAGE_MODEL, USE_IMAGE_API, PANELS_DIR


def _placeholder(prompt, output_path):
    image = Image.new("RGB", (1024, 768), "#f4ead5")
    draw = ImageDraw.Draw(image)
    draw.rectangle((20, 20, 1004, 748), outline="#222222", width=8)
    draw.text((60, 70), "COMICCRAFT DEMO PANEL", fill="#222222")
    draw.text((60, 180), prompt[:300], fill="#333333")
    draw.text((60, 680), "Enable HF_API_KEY and USE_IMAGE_API=true for AI images.", fill="#555555")
    image.save(output_path, format="PNG")
    return output_path


def generate_image(prompt, panel_number):
    filename = f"panel_{panel_number}_{uuid.uuid4().hex[:8]}.png"
    output_path = PANELS_DIR / filename

    if not USE_IMAGE_API or not HF_API_KEY:
        return _placeholder(prompt, output_path)

    endpoint = f"https://api-inference.huggingface.co/models/{HF_IMAGE_MODEL}"
    headers = {"Authorization": f"Bearer {HF_API_KEY}"}
    try:
        with httpx.Client(timeout=180) as client:
            response = client.post(endpoint, headers=headers, json={"inputs": prompt})
            response.raise_for_status()
        image = Image.open(io.BytesIO(response.content)).convert("RGB")
        image.save(output_path, format="PNG")
        return output_path
    except Exception:
        return _placeholder(prompt, output_path)
