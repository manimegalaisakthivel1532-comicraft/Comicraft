from typing import List
from pydantic import BaseModel, Field

class PromptRequest(BaseModel):
    story_prompt: str = Field(..., min_length=3, max_length=2000)
    character_name: str = Field("Alex", min_length=1, max_length=80)
    setting: str = Field("Enchanted forest", max_length=120)
    tone: str = Field("dramatic", max_length=50)
    art_style: str = Field("comic book", max_length=80)

class Panel(BaseModel):
    panel_number: int
    title: str
    scene_description: str
    image_prompt: str
    narration: str = ""
    caption: str = ""
    dialogue: str = ""

class ComicResult(BaseModel):
    title: str
    panels: List[Panel]
    pdf_url: str
