# ComicCraft - AI Comic Story Creator

## Windows setup

```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```

Open:
- http://127.0.0.1:8000
- http://127.0.0.1:8000/docs

Demo mode works without API keys. To enable Gemini, add `GEMINI_API_KEY` to `.env`. To enable remote image generation, add `HF_API_KEY` and set `USE_IMAGE_API=true`.
